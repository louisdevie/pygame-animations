# pygame-animations

[![Documentation Status](https://readthedocs.org/projects/pygame-animations/badge/?version=latest)](https://pygame-animations.readthedocs.io/fr/latest/?badge=latest)

This package is an extension for pygame that lets you animate almost anything.

Documentation can be found at : https://pygame-animations.rtfd.io