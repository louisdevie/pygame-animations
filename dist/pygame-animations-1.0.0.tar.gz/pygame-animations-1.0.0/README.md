# pygame-animations

This package is an extension for pygame that lets you animate almost anything.

Documentation can be found at : https://pygame-animations.rtfd.io