# pygame-animations

This package is an extension for pygame that lets you animate almost anything.